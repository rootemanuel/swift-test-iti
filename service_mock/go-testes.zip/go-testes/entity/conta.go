package entity

type RootEntity struct {
	Contas   []ContaEntity `json:"contas"`
	Contatos []string      `json:"contatos"`
}

type ContaEntity struct {
	Name  string  `json:"name"`
	Saldo float64 `json:"valor"`
}
